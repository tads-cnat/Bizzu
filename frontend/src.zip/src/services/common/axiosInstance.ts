import axios from "axios";
import getLocalStorage from "../../utils/getLocalStorage";

const axiosInstance = axios.create({
  baseURL: "http://localhost:8000/api/",
//   headers: {
//     "Content-Type": "multipart/form-data"; "boundary"="blob"
//   }
});


axiosInstance.interceptors.request.use( ///token ser inserido na requisição automaticamente 
    (config) => {
        const user = getLocalStorage();
        if (user  && user.token){
            const token = user.token;
            config.headers['Authorization'] =  `Bearer ${token}`;
        }
        return config;
    },
    async (error) => {
		await Promise.reject(error);
	}
)


export default axiosInstance;
