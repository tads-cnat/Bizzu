from rest_framework import viewsets
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from api.models import Comunidade 
from api.serializers.comunidade import ComunidadeSerializer

class ComunidadeViewSet(viewsets.ViewSet):
    queryset = Comunidade.objects.all()
    serializer_class = ComunidadeSerializer
    permission_classes = [AllowAny]